package net.javaguides.sms.controller;

import net.javaguides.sms.entity.Worker;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import net.javaguides.sms.service.WorkerService;

@Controller
public class WorkerController {
	
	private WorkerService workerService;

	public WorkerController(WorkerService workerService) {
		super();
		this.workerService = workerService;
	}
	
	@GetMapping("/workers")
	public String listWorkers(Model model) {
		model.addAttribute("workers", workerService.getAllWorker());
		return "workers";
	}
	
	@GetMapping("/workers/new")
	public String createWorkerForm(Model model) {
		
		Worker worker = new Worker();
		model.addAttribute("worker", worker);
		return "create_worker";
		
	}
	
	@PostMapping("/workers")
	public String saveWorker(@ModelAttribute("worker") Worker worker) {
		workerService.saveWorker(worker);
		return "redirect:/workers";
	}
	
	@GetMapping("/workers/edit/{id}")
	public String editWorkerForm(@PathVariable Long id, Model model) {
		model.addAttribute("worker", workerService.getWorkerById(id));
		return "edit_worker";
	}

	@PostMapping("/workers/{id}")
	public String updateWorker(@PathVariable Long id,
			@ModelAttribute("worker") Worker worker,
			Model model) {
		
		Worker existingWorker = workerService.getWorkerById(id);
		existingWorker.setId(id);
		existingWorker.setFirstName(worker.getFirstName());
		existingWorker.setLastName(worker.getLastName());
		existingWorker.setEmail(worker.getEmail());
		
		workerService.updateWorker(existingWorker);
		return "redirect:/workers";
	}
	
	// handler method to handle delete student request

	@GetMapping("/workers/{id}")
	public String deleteStudent(@PathVariable Long id) {
		workerService.deleteWorkerById(id);
		return "redirect:/workers";
	}
	
}
