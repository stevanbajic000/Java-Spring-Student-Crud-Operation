package net.javaguides.sms.service;

import net.javaguides.sms.entity.Worker;

import java.util.List;

public interface WorkerService {
	List<Worker> getAllWorker();
	
	Worker saveWorker(Worker student);
	
	Worker getWorkerById(Long id);
	
	Worker updateWorker(Worker student);
	
	void deleteWorkerById(Long id);
}
