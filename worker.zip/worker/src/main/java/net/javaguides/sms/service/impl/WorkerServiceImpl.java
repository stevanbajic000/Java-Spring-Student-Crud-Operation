package net.javaguides.sms.service.impl;


import net.javaguides.sms.entity.Worker;
import net.javaguides.sms.service.WorkerService;
import org.springframework.stereotype.Service;

import net.javaguides.sms.repository.WorkerRepository;

import java.util.List;

@Service
public class WorkerServiceImpl implements WorkerService {

	private WorkerRepository workerRepository;
	
	public WorkerServiceImpl(WorkerRepository workerRepository) {
		super();
		this.workerRepository = workerRepository;
	}

	@Override
	public List<Worker> getAllStudents() {
		return workerRepository.findAll();
	}

	@Override
	public Worker saveWorker(Worker worker) {
		return workerRepository.save(worker);
	}

	@Override
	public Worker getWorkerById(Long id) {
		return workerRepository.findById(id).get();
	}

	@Override
	public Worker updateWorker(Worker student) {
		return workerRepository.save(student);
	}

	@Override
	public void deleteWorkerById(Long id) {
		workerRepository.deleteById(id);
	}

}
